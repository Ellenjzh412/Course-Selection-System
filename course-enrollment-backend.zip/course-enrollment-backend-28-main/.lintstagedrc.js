module.exports = {
  '{,src/**/}*.{md,json,yml,html,java}': ['prettier --write'],
};
